#!/bin/bash
 
USER="root"
PASSWORD="synerzip"
OUTPUT="/home/synerzip/unix/database"
rm -rf $OUTPUT/`date +%Y%m%d`.*

databases=`mysql --user=$USER --password=$PASSWORD -e "SHOW DATABASES;" | tr -d "| " | grep -v Database`
 
for db in $databases; do
    if [ "$db" != "information_schema" ] ; then
        echo "Dumping database: $db"
        mysqldump --force --opt --user=$USER --password=$PASSWORD --databases $db > $OUTPUT/`date +%Y%m%d`.$db.sql
        gzip $OUTPUT/`date +%Y%m%d`.$db.sql
    fi
done