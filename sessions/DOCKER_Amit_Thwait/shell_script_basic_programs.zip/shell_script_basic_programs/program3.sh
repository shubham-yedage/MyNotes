#!/bin/bash
echo "Enter file path: "; read x
if [ -e $x ]; then
	echo "file is present"; 
else
	echo "The directory $x does not exist";
	exit 1
fi