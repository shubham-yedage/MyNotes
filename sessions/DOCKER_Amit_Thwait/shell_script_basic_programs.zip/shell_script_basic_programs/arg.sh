#!/bin/bash
for arg in $*;do
	echo "argument is : "$arg
done	